### JWT 테스트용

1. Bearer 방식
- id, pw를 통해서 token을 만들고 token을 달아서 요청하는 방식.
- 